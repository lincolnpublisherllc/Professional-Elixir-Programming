|> Task.async_stream(fn file ->
  File.read!(file)
  |> String.split()
  |> Enum.count()
end, max_concurrency: 3)
|> Enum.to_list()
Professional Insight:Elixir’s functional, concurrent nature allows 
safe and efficient algorithms without worrying about race conditions, making it ideal for distributed systems.
