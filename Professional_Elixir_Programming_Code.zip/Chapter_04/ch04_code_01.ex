Elixir provides several built-in data structures, each optimized for specific operations:
