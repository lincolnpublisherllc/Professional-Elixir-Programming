Optimized for pattern matching and fixed-length storage:
{x, y} = {10, 20}
Performance Note: Accessing tuple elements is faster than list access for small collections.
4.1.5 ETS (Erlang Term Storage)
