Table types: :set, :ordered_set, :bag
:ets.new(:users, [:set, :public, :named_table])
:ets.insert(:users, {1, "Alice"})
:ets.lookup(:users, 1)
Use Case: Caching, shared state across processes.
