|> Stream.filter(&rem(&1, 2) == 0)
|> Stream.map(&(&1 * 2))
|> Enum.take(5)
# => [4, 8, 12, 16, 20]
