|> Enum.map(&Map.put(&1, :active, true))
|> Enum.each(fn user -> :ets.insert(:active_users, {user.id, user}) end)
