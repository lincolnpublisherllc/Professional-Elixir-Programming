ListUtils.sum([1,2,3,4])
# => 10
