Streams avoid building large intermediate collections:
