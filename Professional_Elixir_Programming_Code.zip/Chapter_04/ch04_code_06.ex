# Insertion example
def insert(nil, value), do: %BinaryTree{value: value}
def insert(%BinaryTree{value: v, left: l, right: r} = node, value) when value < v do
  %BinaryTree{node | left: insert(l, value)}
