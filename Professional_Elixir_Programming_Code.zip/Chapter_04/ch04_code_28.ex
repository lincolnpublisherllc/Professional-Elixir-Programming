4.5.1 Example: Top-N Frequent Elements
defmodule TopN do
  def frequent_elements(list, n) do
    list
    |> Enum.frequencies()
    |> Enum.sort_by(fn {_k, v} -> -v end)
    |> Enum.take(n)
    |> Enum.map(fn {k,_v} -> k end)
  end
