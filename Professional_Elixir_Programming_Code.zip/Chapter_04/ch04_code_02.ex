Common operations:
iex> set1 = MapSet.new([1, 2, 3])
iex> set2 = MapSet.new([3, 4, 5])
iex> MapSet.union(set1, set2)
#MapSet< [1, 2, 3, 4, 5] >
Use Case: Eliminating duplicates in pipelines, membership checks.
