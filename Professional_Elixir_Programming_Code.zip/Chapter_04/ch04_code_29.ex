TopN.frequent_elements([1,2,2,3,3,3,4], 2)
# => [3, 2]
4.5.2 Example: Parallel File Processing
files = ["file1.txt", "file2.txt", "file3.txt"]
