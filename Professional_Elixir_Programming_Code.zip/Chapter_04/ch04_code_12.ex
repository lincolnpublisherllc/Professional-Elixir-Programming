Elixir’s functional paradigm encourages recursion over iteration:
