defmodule Factorial do
  def calculate(n), do: factorial(n, 1)
