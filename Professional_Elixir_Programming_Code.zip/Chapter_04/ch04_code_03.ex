Nested maps support complex structures:
user = %{id: 1, name: "Alice", preferences: %{theme: "dark"}}
