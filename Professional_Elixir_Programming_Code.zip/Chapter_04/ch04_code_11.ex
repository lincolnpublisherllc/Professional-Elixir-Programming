Supports complex queries, tables, and transactions:
:mnesia.create_schema([node()])
:mnesia.start()
:mnesia.create_table(:users, [{:attributes, [:id, :name]}])
Use Case: Distributed systems requiring atomic multi-node operations.
