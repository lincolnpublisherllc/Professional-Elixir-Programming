Factorial.calculate(5)
# => 120
