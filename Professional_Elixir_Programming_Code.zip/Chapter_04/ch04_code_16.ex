  defp factorial(0, acc), do: acc
  defp factorial(n, acc), do: factorial(n-1, acc * n)
