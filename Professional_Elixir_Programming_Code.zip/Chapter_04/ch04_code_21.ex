O(n)
O(n)
O(1)
O(1)
Trade-Off Example:
