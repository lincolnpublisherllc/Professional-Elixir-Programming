def insert(%BinaryTree{value: v, left: l, right: r} = node, value) when value >= v do
  %BinaryTree{node | right: insert(r, value)}
