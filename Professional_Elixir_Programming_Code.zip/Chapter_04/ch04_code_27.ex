|> Task.async_stream(fn n -> n * n end, max_concurrency: 10)
|> Enum.to_list()
