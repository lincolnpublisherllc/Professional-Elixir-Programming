Use Case: Efficient searches, priority queues.
