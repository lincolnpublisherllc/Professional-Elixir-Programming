While Elixir doesn’t have built-in trees, you can implement functional binary trees:
defmodule BinaryTree do
  defstruct value: nil, left: nil, right: nil
