Professional Challenge:Build a 
distributed word frequency analyzer that reads large text files concurrently, stores intermediate results in ETS, and outputs the top 10 most frequent words across files.
