|> Stream.map(&(&1 * 3))
|> Stream.filter(&rem(&1, 2) == 0)
|> Enum.take(10)
