Use Task.async_stream to process data concurrently:
