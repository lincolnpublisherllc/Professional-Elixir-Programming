Performance Tip: Use atoms as keys for performance-critical systems, but avoid dynamic atoms in production to prevent atom table exhaustion.
