Role: Work on deploying, scaling, and maintaining Elixir systems in production, ensuring availability, performance, and fault tolerance.
Skills: Experience with Docker, Kubernetes, CI/CD, and cloud platforms like AWS, Google Cloud, and Azure.
