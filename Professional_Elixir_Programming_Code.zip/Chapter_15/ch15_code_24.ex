Role: Lead the design and architecture of complex, highly-scalable Elixir applications. Focus on system design, performance optimization, and scalability.
Skills: In-depth knowledge of Elixir’s concurrency model, distributed computing, event-driven architecture, and microservices.
