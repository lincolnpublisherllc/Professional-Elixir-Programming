The rise of cloud-native development and microservices has further accelerated the adoption of FP languages like Elixir, Haskell, and F# in high-availability systems.
