Follow Elixir conferences: ElixirConf and other Elixir-related events are excellent opportunities for networking and learning.
