Role: You will be responsible for developing both the backend and frontend of Elixir-based web applications.
Skills: Proficiency in Phoenix, Phoenix LiveView, Ecto, and real-time communication with Channels.
