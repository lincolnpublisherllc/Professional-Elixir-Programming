Role: Build systems that handle massive concurrency, real-time data processing, and fault tolerance.
Skills: Expertise in GenServer, GenStage, ETS, distributed Elixir, and supervision trees.
