Role: Contribute to the Elixir ecosystem by writing libraries, frameworks, or providing improvements to the core language or tools.
Skills: Strong open-source experience, contributing to projects like Phoenix, Ecto, or Nerves.
