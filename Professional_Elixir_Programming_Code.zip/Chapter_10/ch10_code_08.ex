10.2 Telecommunication and IoT Applications
10.2.1 Telecommunication: WhatsApp
