10.1.3 E-Commerce Platforms: Spree Commerce with Elixir
