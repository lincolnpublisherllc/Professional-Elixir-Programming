Professional Challenge:Design and build a 
real-time Elixir application with Phoenix Channels and GenServer to handle user interactions. Implement horizontal scaling and ensure that the system can recover gracefully from failures.
