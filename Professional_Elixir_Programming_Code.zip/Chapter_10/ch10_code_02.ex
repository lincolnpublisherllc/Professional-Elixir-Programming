10.1.1 Messaging Systems: Discord
