AWS: EC2, ECS, Lambda (with serverless Elixir via AWS Lambda runtime)
Azure: App Service, AKS (Kubernetes)
Google Cloud: GCE, GKE, Cloud Run
