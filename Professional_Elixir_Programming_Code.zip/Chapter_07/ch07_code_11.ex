Setup Example:
defp deps do
  [
    {:grpc, "~> 0.5.0"},
    {:protobuf, "~> 0.12"}
  ]
