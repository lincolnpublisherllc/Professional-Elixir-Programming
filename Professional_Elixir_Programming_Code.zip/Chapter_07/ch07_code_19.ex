Use Telemetry, Prometheus, Grafana for real-time metrics.
Track:
