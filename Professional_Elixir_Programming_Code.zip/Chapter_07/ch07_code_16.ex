Example: Consuming messages
{:ok, _pid} = :brod.start_link_client([{"localhost", 9092}], :client)
:brod.start_link_consumer(:client, "topic_name", "consumer_group", self())
