Database Configuration (config/config.exs):
config :my_app, MyApp.Repo,
  username: "postgres",
  password: "postgres",
  database: "my_app_db",
  hostname: "localhost",
  pool_size: 10
Schema Example:
defmodule MyApp.User do
  use Ecto.Schema
  import Ecto.Changeset
