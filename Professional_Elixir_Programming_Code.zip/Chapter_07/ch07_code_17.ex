{:ok, conn} = AMQP.Connection.open("amqp://guest:guest@localhost")
{:ok, chan} = AMQP.Channel.open(conn)
AMQP.Queue.declare(chan, "task_queue")
AMQP.Basic.publish(chan, "", "task_queue", "Message Body")
Use Cases: Asynchronous messaging, event-driven microservices, real-time notifications.
