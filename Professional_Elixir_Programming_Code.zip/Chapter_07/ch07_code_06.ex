Example:
{:ok, conn} = Mongo.start_link(url: "mongodb://localhost:27017/my_db")
Mongo.insert_one(conn, "users", %{name: "Alice", age: 30})
Use Cases: flexible schemas, document-based storage, rapid prototyping.
