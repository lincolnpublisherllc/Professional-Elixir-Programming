Example (HTTPoison):
HTTPoison.get!("https://api.example.com/users")
|> Map.get(:body)
|> Jason.decode!()
Use Cases: Microservices, external APIs, SaaS integration.
