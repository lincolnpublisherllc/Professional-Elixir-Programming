Redis or ETS (Erlang Term Storage) enables fast, ephemeral storage.
ETS Example:
:ets.new(:cache_table, [:named_table, :public])
:ets.insert(:cache_table, {:user_1, %{name: "Alice", email: "alice@mail.com"}})
{:ok, user} = :ets.lookup(:cache_table, :user_1)
Use Cases: caching, session storage, real-time counters.
