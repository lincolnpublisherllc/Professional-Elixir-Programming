Professional Challenge:Build a 
distributed Elixir service that reads from a Kafka topic, stores results in PostgreSQL, exposes a GraphQL API for clients, and is deployable to AWS. Include logging and performance monitoring for production readiness.
