Logger.info("User signed in", user_id: 42)
Integrate with external logging platforms: ELK stack, Datadog, or Papertrail.
