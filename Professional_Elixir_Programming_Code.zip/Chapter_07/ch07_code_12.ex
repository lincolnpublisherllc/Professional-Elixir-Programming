Use Cases: Low-latency RPC, multi-language service communication.
