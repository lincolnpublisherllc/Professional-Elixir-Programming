Example:
# Schema
object :user do
  field :id, :id
  field :name, :string
  field :email, :string
