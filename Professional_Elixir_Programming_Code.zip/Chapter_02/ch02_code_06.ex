Example: Implementing a GenServer requires adhering to the GenServer behaviour.
defmodule MyServer do
  use GenServer
