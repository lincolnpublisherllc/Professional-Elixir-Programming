Common in testing frameworks, config libraries, and internal business rule engines.
