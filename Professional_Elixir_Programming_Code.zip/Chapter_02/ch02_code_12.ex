defimpl Stringifiable, for: List do
  def to_string(value), do: Enum.join(value, ", ")
