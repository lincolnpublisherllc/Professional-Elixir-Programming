defimpl Stringifiable, for: Integer do
  def to_string(value), do: Integer.to_string(value)
