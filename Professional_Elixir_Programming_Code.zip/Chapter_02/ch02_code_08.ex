  @impl true
  def handle_call(:ping, _from, state) do
    {:reply, :pong, state}
  end
