MacroExample.say_hello("Busayo")
