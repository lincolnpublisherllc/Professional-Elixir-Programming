Professional Challenge:Create a mini DSL for defining scheduled jobs using macros. The DSL should allow users to declare jobs with a 
run_every/2 macro, generate corresponding modules dynamically, and validate the schedule at compile time.
