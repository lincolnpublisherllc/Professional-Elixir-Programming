Mimic higher-level frameworks (e.g., Phoenix)
