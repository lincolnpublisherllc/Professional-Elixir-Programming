  get "/home" do
    IO.puts("Home page logic")
  end
