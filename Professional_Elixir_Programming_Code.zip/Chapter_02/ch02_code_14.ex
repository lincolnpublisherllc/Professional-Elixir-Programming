defmodule DynamicLoader do
  def load(module_string) do
    {module, _} = Code.eval_string(module_string)
    module
  end
