Example: Define routes for a web application.
defmodule RouterDSL do
  defmacro get(path, do: block) do
    quote do
      IO.puts("Register GET route: #{unquote(path)}")
      unquote(block)
    end
  end
