Schema definitions (schema) use macros to auto-generate getter/setter and validation functions.
Oban (Job Processing)
