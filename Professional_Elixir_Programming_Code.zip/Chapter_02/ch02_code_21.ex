Output:
Register GET route: /home
