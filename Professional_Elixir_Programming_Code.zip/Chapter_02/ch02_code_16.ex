Module module allows introspection:
Module.definitions_in(MyServer)
# Returns list of functions: [{:init, 1}, {:handle_call, 3}]
Use case: Generate documentation, analyze code, or implement dynamic dispatch.
