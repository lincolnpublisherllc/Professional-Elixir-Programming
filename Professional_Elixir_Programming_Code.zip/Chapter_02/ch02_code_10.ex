Example: A Stringifiable protocol:
defprotocol Stringifiable do
  @doc "Converts a value to a string"
  def to_string(value)
