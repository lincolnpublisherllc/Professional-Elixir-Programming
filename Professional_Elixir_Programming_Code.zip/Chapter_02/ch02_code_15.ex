DynamicLoader.load("defmodule Hello do; def greet, do: 'Hi'; end")
Hello.greet()
# Output: "Hi"
