@impl true ensures compliance with the expected callbacks.
