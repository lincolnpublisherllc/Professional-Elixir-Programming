Use:
Stringifiable.to_string([1, 2, 3])
# Output: "1, 2, 3"
