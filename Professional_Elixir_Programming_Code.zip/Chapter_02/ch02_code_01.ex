Macros are functions that receive quoted expressions (abstract syntax trees) and return transformed code.
