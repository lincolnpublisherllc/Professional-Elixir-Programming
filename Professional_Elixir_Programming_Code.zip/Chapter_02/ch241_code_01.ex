2.1.3 Practical Use Cases42
