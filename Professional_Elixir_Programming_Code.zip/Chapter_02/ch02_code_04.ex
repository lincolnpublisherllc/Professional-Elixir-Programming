unquote injects runtime values into the quoted expression.
Output:
