mix deps.get
mix docs
