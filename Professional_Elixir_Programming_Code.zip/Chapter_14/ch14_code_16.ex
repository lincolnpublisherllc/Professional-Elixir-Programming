Professional Challenge:Contribute to an open-source 
Elixir project. Start by fixing a bug, writing documentation, or adding a small feature. Afterward, write a blog post detailing your contribution process and lessons learned.
