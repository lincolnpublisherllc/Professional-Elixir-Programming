Join Elixir-related forums, mailing lists, and Slack channels. Participate in discussions about:
