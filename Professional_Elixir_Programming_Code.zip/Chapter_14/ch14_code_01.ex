Phoenix: The popular web framework.
Ecto: Database wrapper and query engine.
Nerves: Embedded systems framework.
Broadway: Data processing pipeline library.
Finding Projects:
GitHub: Search for Elixir repositories with tags like #elixir, #opensource, or #elixir-framework.
Hex: Many libraries on Hex are open-source, and many require contributions to improve.
Elixir Community: Follow forums, such as elixir-lang slack, Elixir Forum, and Twitter hashtags like #ElixirLang to find projects needing help.
