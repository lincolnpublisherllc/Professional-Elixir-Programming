Fault-tolerant GenServers for sensor data aggregation.
