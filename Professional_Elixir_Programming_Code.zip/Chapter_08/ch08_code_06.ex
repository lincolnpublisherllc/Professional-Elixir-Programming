Authorization ensures that authenticated users have appropriate permissions:
Example: Plug-based Role Checks
defmodule MyAppWeb.Plugs.Authorize do
  import Plug.Conn
