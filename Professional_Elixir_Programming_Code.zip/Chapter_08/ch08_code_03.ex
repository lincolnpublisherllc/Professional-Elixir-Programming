  def subject_for_token(user, _claims) do
    {:ok, to_string(user.id)}
  end
