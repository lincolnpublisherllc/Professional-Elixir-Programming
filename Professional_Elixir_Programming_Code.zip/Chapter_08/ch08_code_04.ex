  def resource_from_claims(%{"sub" => id}) do
    {:ok, MyApp.Users.get_user!(id)}
  end
