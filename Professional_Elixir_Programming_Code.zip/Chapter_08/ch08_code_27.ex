Use supervision trees and GenServers for fault tolerance.
