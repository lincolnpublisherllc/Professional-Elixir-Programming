Supervisor Example:
children = [
  {MyApp.Worker, []}
