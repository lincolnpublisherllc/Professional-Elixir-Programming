  schema "users" do
    field :email, Cloak.Ecto.Binary, vault: MyApp.Vault
    timestamps()
  end
