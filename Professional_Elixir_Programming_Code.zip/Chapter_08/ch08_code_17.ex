Use Task.retry patterns or custom retry logic for transient errors.
def retry(fun, attempts \\ 3)
def retry(_fun, 0), do: {:error, "Max retries reached"}
def retry(fun, attempts) do
  case fun.() do
    {:ok, result} -> {:ok, result}
    {:error, _} -> retry(fun, attempts - 1)
  end
