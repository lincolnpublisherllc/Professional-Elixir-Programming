Supervisor.start_link(children, strategy: :one_for_one)
Strategies:
:one_for_one – Restart the failing process.
:one_for_all – Restart all children if one fails.
:rest_for_one – Restart failing process and those started after it.
