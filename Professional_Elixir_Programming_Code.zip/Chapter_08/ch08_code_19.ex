8.4.1 Supervisors and GenServers
Supervisors monitor worker processes for failures.
GenServers maintain stateful services reliably.
Example: GenServer with Recovery
defmodule MyApp.CacheServer do
  use GenServer
