Professional Challenge:Build a 
secure, resilient Elixir API service that integrates JWT-based authentication, communicates over HTTPS, includes retries for transient errors, and demonstrates supervision tree recovery under simulated failures.
