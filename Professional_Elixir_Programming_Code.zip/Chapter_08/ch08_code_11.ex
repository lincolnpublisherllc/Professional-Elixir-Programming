Plug SSL Enforcement Example:
# In endpoint.ex
plug Plug.SSL, rewrite_on: [:x_forwarded_proto], host: "www.myapp.com"
Best Practices:
Use HTTP Strict Transport Security (HSTS).
Renew certificates automatically (e.g., Let's Encrypt).
