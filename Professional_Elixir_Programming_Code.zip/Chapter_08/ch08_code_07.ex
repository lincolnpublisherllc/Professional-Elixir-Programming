  def init(default), do: default
