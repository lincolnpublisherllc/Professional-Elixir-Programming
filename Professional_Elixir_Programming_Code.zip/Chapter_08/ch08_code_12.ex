At rest: Encrypt sensitive database columns (e.g., AES-256).
In transit: Use SSL/TLS for API requests and message queues.
Example: Encrypting fields with Cloak:
defmodule MyApp.User do
  use Ecto.Schema
  import Ecto.Changeset
  use Cloak.Ecto.Schema
