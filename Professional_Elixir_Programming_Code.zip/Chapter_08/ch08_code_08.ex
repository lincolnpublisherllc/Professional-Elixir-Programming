  def call(conn, roles) do
    user_role = conn.assigns.current_user.role
    if user_role in roles, do: conn, else: send_resp(conn, 403, "Forbidden") |> halt()
  end
