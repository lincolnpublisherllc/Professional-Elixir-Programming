9.1.2 Using Benchee113
