Inspect GenServer states, active tasks, and message queues in real-time.
9.3.3 Logger and Telemetry
Use Logger with custom metadata for structured logging:
Logger.info("Processing request", request_id: 1234)
Telemetry provides metrics on function execution, database queries, and system events, essential for performance monitoring.
