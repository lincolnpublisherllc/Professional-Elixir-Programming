Professional Challenge:Build a 
clustered Elixir service that handles concurrent requests. Profile CPU and memory, identify bottlenecks, optimize critical paths, and monitor the system live using Observer and Telemetry. Provide a written summary of before-and-after performance metrics.
