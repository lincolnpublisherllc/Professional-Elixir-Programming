9.1.2 Using Benchee
Benchee is a popular Elixir library for measuring execution time, memory usage, and statistical analysis.
Example: Benchmarking Sorting Algorithms
Benchee.run(%{
  "QuickSort" => fn -> Enum.sort([5,3,8,1,2]) end,
  "InsertionSort" => fn -> insertion_sort([5,3,8,1,2]) end
})
Output:
