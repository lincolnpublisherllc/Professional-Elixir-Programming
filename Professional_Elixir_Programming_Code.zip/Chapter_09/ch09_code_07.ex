Use :observer.start() to monitor process memory usage.
