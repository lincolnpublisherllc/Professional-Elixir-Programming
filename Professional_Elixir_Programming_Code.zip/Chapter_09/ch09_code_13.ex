Common bottlenecks in Elixir:
