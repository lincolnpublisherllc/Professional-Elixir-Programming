Observer provides a graphical interface to:
