Blocking GenServer calls for long-running operations.
