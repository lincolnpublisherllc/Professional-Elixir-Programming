ExProf: Function-level profiling for bottleneck identification.
fprof: Built-in Erlang profiler for CPU-heavy tasks.
Flow Benchmarks: Use for pipelines and parallel processing comparisons.
