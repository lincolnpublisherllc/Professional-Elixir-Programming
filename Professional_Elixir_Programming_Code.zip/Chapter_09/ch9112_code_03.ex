9.3.3 Logger and Telemetry116
