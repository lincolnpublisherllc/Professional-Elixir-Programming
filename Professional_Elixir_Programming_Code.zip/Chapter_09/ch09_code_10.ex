Launch Example:
:observer.start()
