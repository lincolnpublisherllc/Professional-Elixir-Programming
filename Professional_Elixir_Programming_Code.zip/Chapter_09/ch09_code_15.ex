Parallelize tasks with Task.async or GenStage pipelines.
