Use :fprof for function-level CPU time.
:fprof.start()
:fprof.trace(:start)
MyApp.ExpensiveFunction.run()
:fprof.trace(:stop)
:fprof.profile()
:fprof.analyse()
