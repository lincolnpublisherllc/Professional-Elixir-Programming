  test "user creation" do
    user = %User{name: "Alice", email: "alice@example.com"}
    assert user.name == "Alice"
  end
