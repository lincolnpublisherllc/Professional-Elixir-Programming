Structure your code to separate concerns:
Business logic: Keep business rules separate from infrastructure (e.g., HTTP, database, etc.).
Pure functions: Elixir’s functional nature encourages side-effect-free functions, making code more predictable.
