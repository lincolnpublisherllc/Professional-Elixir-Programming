Use Credo to enforce common style guidelines:
mix deps.get
mix credo --strict
