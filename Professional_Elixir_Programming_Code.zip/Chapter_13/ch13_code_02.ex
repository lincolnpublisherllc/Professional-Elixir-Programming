Naming Conventions: Use descriptive names for functions, modules, and variables to improve readability.
Example:
# Good
def get_user_by_id(id), do: Repo.get(User, id)
