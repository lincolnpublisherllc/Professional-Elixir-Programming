jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout code
        uses: actions/checkout@v2
      - name: Setup Elixir
        uses: actions/setup-elixir@v1
      - name: Install dependencies
        run: mix deps.get
      - name: Run tests
        run: mix test
Automated Deployment: Automate the deployment process to your production environment after successful tests, using releases:
mix release
