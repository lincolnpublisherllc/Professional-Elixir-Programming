# Bad
def get_user(x), do: Repo.get(User, x)
Avoid overcomplicating logic: Break down large functions into smaller, single-responsibility functions.
