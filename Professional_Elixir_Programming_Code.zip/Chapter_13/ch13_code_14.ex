Test the codebase: Every commit should trigger automated testing:
name: Elixir CI
