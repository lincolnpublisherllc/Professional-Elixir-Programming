Example:
defmodule MyApp.UserTest do
  use ExUnit.Case
  alias MyApp.User
