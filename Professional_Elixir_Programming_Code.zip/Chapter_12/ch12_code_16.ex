  test "creates a user", %{conn: conn} do
    conn = post(conn, Routes.user_path(conn, :create), user: %{name: "Alice", email: "alice@example.com"})
    assert html_response(conn, 200)
  end
