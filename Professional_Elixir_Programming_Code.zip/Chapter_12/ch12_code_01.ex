Functional Requirements: What is the core business logic? What features does the system need to provide? Examples might include:
Real-time communication (messaging, chat)
