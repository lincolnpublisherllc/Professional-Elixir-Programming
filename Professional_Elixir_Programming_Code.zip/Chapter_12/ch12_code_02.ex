External API integrations (payment gateways, third-party services)
