Create the Elixir project:
mix new my_large_scale_project --module MyLargeScaleApp --no-ecto
