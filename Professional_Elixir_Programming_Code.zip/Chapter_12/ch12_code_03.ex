Non-Functional Requirements: How should the system scale, perform, and remain resilient? Consider:
Scalability: How should the system handle increased traffic or data volume?
Fault Tolerance: What happens when a process or server fails?
Availability: How can the system ensure high uptime and minimal downtime?
Maintainability: How can the codebase be kept modular, clean, and easy to maintain over time?
