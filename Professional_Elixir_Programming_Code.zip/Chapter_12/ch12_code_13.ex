Use Ecto for interacting with your SQL database (e.g., PostgreSQL):
