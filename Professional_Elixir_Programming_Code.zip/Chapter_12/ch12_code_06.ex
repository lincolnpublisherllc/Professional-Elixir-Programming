Add dependencies: In mix.exs, include necessary dependencies:
defp deps do
  [
    {:phoenix, "~> 1.6.0"},
    {:ecto_sql, "~> 3.7"},
    {:postgrex, ">= 0.0.0"},
    {:jason, "~> 1.2"},
    {:phoenix_ecto, "~> 4.2"}
  ]
