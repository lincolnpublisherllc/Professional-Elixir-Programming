  def handle_event([:phoenix, :endpoint, :stop], _measurements, _metadata, _config) do
    IO.puts("Request processed successfully")
  end
