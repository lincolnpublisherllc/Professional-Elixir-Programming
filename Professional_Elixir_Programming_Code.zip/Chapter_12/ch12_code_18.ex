Example: Telemetry setup
defmodule MyApp.Metrics do
  def setup do
    :telemetry.attach("http-request-metrics", [:phoenix, :endpoint, :stop], &handle_event/4, nil)
  end
