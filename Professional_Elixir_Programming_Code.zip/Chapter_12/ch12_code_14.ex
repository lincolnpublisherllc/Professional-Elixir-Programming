Example: HTTPoison for making an API request
defmodule MyApp.Payment do
  def create_payment_intent(amount) do
    url = "https://api.stripe.com/v1/payment_intents"
    headers = [
      {"Authorization", "Bearer sk_test_12345"}
    ]
    body = {:form, [amount: amount]}
    HTTPoison.post(url, body, headers)
  end
