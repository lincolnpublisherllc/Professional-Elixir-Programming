GenServer and Task manage game state, player actions, and world updates.
Example: Game Server using Phoenix Channels
defmodule GameChannel do
  use Phoenix.Channel
