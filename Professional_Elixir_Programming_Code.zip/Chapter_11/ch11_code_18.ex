Mnesia Database: Ideal for building distributed and fault-tolerant financial systems that require transactional integrity.
Event Sourcing: Store changes to state as events, and process them asynchronously.
