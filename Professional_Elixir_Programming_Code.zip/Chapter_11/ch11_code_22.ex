Telemetry for real-time system metrics and logging.
