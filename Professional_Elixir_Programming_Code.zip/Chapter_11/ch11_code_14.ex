Example: GenServer-based transaction processing
defmodule TradingServer do
  use GenServer
