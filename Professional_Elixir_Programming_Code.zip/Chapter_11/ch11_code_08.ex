Use Case: Multiplayer Game Servers
