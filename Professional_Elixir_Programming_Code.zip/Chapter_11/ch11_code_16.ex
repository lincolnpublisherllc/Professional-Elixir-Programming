  def handle_cast({:buy, amount, price}, state) do
    new_state = update_state(state, amount, price)
    {:noreply, new_state}
  end
