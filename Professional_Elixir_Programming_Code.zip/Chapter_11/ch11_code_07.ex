Nx: A numerical computing library in Elixir, ideal for building scientific and machine learning applications. It allows you to work with tensor data structures similar to NumPy in Python.
ExMath: An Elixir library for performing mathematical operations on complex numbers, matrices, etc.
