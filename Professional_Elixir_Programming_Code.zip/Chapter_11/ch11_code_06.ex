results = Enum.map(tasks, fn task -> Task.await(task) end)
Benefits of Elixir:
