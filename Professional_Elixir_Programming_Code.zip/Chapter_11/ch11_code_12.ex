GenServer can maintain state for each simulation process.
Use GenStage for handling data streams between different parts of the system.
