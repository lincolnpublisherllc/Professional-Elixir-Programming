Use linting tools (Credo) to enforce best practices:
mix deps.get
mix credo --strict
