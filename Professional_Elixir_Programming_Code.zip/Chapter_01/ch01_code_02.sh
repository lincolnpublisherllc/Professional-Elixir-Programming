Elixir runs on the Erlang VM (BEAM). Before installing Elixir, install a compatible Erlang/OTP version.
Use asdf version manager or system package managers for version control.
Command example for Ubuntu using asdf:
asdf plugin-add erlang
asdf install erlang 26.2
asdf global erlang 26.2
Verify installation:
erl -version
