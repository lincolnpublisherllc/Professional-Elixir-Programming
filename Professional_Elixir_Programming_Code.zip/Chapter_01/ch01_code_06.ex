asdf: Manages multiple Elixir/Erlang versions; essential for projects with varying OTP requirements.
Homebrew / apt / Chocolatey: System-level installations are useful but less flexible in multi-project setups.
