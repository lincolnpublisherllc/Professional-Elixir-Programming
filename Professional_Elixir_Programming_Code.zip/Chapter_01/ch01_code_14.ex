Standard Elixir project structure:
