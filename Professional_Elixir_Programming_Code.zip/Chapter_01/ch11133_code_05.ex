11.4.1 Elixir for Financial Applications139
Example: High-Frequency Trading System140
