Extension: ElixirLS: Elixir support and debugger.
Features:
