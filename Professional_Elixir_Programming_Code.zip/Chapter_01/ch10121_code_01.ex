Case Studies: Enterprise Systems Written in Elixir121
