Example: AI Model Inference134
