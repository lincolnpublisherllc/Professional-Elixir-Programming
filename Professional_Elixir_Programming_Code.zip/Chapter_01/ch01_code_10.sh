Common commands:
mix new my_app      # create a new project
mix compile         # compile the project
mix test            # run tests
mix docs            # generate documentation
