Professional Challenge:Create a new Elixir project, integrate two dependencies via Hex, configure separate dev/test/prod environments, and write a Mix task that prints system information automatically. Ensure the code passes 
Credo linting and all tests succeed.
