Automate repetitive tasks using Mix tasks:
defmodule Mix.Tasks.MyTask do
  use Mix.Task
  @shortdoc "Example automated task"
  def run(_) do
    IO.puts("Task executed")
  end
