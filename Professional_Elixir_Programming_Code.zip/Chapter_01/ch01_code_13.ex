Best practice: Keep environment-specific secrets in config/runtime.exs.
