Again, asdf is highly recommended for managing multiple versions:
asdf plugin-add elixir
asdf install elixir 1.18.2
asdf global elixir 1.18.2
Confirm:
elixir --version
