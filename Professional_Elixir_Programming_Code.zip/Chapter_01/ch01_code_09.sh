The mix build tool and Hex package manager are fundamental to professional Elixir workflows.
