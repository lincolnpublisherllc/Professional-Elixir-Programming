Shell enhancements (zsh + oh-my-zsh) can accelerate command execution.
