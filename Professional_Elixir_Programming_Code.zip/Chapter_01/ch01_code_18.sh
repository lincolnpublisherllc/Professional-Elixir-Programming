Code formatting: mix format
Linting and static analysis: mix credo
Running tests automatically: mix test --trace
Database migrations: mix ecto.migrate
