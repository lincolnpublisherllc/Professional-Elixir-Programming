Adding dependencies in mix.exs:
defp deps do
  [
    {:httpoison, "~> 2.1"},
    {:jason, "~> 1.4"}
  ]
