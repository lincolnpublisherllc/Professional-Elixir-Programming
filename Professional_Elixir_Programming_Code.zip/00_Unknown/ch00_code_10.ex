Step 1: Scan the QR Code or Click the Link6
Step 2: Go to the Repository Page6
Step 3: Download the ZIP File7
Step 4: Extract the Files7
Step 5: Import into Unity7
