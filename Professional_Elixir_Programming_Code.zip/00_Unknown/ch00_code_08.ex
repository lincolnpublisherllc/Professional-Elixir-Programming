Step 5: Import into Unity
