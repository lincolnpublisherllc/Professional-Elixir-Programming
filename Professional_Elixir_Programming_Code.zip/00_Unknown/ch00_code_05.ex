Step 2: Go to the Repository Page
