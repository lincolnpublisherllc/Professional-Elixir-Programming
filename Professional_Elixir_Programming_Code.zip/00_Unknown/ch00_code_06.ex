Step 3: Download the ZIP File
