Step 1: Scan the QR Code or Click the Link
