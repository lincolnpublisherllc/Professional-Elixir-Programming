  def init(initial), do: {:producer, initial}
