Isolate state in processes:
