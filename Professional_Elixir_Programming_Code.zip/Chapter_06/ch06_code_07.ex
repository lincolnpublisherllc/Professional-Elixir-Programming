Supervisors isolate failures, keeping systems highly available.
