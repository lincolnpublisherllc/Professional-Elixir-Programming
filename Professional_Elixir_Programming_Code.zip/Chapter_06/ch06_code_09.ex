Asynchronous execution:
task = Task.async(fn -> 1 + 2 end)
result = Task.await(task)
IO.inspect(result) # 3
Use cases: Parallel API calls, background processing.
6.2.2 GenServer
