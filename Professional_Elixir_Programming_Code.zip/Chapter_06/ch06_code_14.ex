  def handle_cast(:increment, state), do: {:noreply, state + 1}
  def handle_call(:get, _from, state), do: {:reply, state, state}
