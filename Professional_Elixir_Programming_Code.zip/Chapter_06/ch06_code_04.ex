  defp loop(messages) do
    receive do
      {:message, msg} ->
        IO.puts("Received: #{msg}")
        loop([msg | messages])
    end
  end
