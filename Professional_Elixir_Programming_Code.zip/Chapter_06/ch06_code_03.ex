Example:
defmodule ActorExample do
  def start do
    spawn(fn -> loop([]) end)
  end
