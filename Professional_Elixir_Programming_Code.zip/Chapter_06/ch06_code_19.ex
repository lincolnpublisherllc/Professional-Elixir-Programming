Example:
Node.start(:node1@localhost)
Node.connect(:node2@localhost)
Processes on different nodes can send messages transparently:
send({:my_process, :node2@localhost}, {:msg, "Hello"})
