  def increment do
    GenServer.cast(__MODULE__, :increment)
  end
