defmodule Producer do
  use GenStage
