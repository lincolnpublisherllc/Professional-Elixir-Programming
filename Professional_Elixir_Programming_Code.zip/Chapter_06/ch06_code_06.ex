  def start(_type, _args) do
    children = [
      MyApp.WorkerA,
      MyApp.WorkerB
    ]
    Supervisor.start_link(children, strategy: :one_for_one)
  end
