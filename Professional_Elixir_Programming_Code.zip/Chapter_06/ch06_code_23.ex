Use supervision trees extensively:
