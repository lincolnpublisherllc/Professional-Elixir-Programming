  def handle_demand(demand, state) do
    events = Enum.to_list(1..demand)
    {:noreply, events, state}
  end
