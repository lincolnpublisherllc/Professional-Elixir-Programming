6.2 Async Patterns: Tasks, GenServer, GenStage
