GenStage: Automatic demand-based flow control.
Task.Supervisor: Limits concurrent tasks.
Task.Supervisor.async_stream(MyApp.TaskSupervisor, 1..1000, fn x ->
  process(x)
end, max_concurrency: 10)
Principle: Always match work supply to consumption rate.
