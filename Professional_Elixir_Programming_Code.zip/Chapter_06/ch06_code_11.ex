  def start_link(initial) do
    GenServer.start_link(__MODULE__, initial, name: __MODULE__)
  end
