Async patterns with Tasks, GenServer, and GenStage.
