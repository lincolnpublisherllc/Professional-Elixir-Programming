Elixir Processes:
Lightweight (millions can run concurrently).
