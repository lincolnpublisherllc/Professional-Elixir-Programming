  def get do
    GenServer.call(__MODULE__, :get)
  end
