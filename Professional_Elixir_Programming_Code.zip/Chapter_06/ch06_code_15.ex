Benefit: Encapsulates state safely, leverages BEAM’s concurrency model.
6.2.3 GenStage
