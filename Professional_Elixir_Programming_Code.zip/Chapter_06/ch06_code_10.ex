Handles sync (call) and async (cast) messages.
Example:
defmodule Counter do
  use GenServer
