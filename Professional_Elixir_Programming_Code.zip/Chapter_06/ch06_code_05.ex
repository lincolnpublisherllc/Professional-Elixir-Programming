Supervisor strategies:
:one_for_one: Restart only the failed process.
:one_for_all: Restart all processes if one fails.
:rest_for_one: Restart failed process and subsequent children.
Example:
defmodule MyApp.Application do
  use Application
