Example directory structure:
