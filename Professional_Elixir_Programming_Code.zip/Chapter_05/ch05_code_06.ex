5.1.2 Hexagonal (Ports & Adapters)
Separates core logic from external systems (database, API, UI).
