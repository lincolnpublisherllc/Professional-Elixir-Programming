5.1.2 Hexagonal (Ports & Adapters)72
