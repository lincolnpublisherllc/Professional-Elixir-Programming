defmodule MyApp.Adapters.Database do
  def fetch_data do
    # Interaction with DB
    MyApp.Repo.all(MyApp.Schema)
  end
