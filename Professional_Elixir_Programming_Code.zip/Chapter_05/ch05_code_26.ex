Cons:
Requires orchestration (Kubernetes, Docker).
