Architecture Decisions:
Event-driven pipeline: Messages processed via Broadway.
ETS caching: Recent messages stored in-memory for fast access.
PostgreSQL: Persistent storage for historical messages.
Supervisor trees: Each chat room handled by a dedicated GenServer.
Module Example:
defmodule ChatRoom do
  use GenServer
