Professional Insight:Decoupling modules increases 
fault tolerance, allowing BEAM to restart only affected components.
