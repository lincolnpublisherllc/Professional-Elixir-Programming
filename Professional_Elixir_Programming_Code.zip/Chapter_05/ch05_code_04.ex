Example:
defmodule MyAppWeb.Controller do
  def show(conn, params) do
    data = MyApp.Service.fetch_data(params["id"])
    render(conn, "show.html", data: data)
  end
