Identify independent components:
