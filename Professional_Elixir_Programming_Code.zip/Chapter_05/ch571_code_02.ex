5.5 Case Study: Scalable Elixir System Design78
Scenario: Real-Time Chat System78
