  def start(_type, _args) do
    children = [
      MyApp.Repo,
      MyAppWeb.Endpoint,
      {MyApp.Worker, []}
    ]
    Supervisor.start_link(children, strategy: :one_for_one)
  end
