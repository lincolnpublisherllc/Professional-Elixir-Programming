Divides the system into layers (e.g., presentation, business logic, data).
Pros:
