In this chapter, you learned:
Key architectural patterns: layered, hexagonal, and event-driven.
