  def handle_cast({:new_message, message}, state) do
    {:noreply, %{state | messages: [message | state.messages]}}
  end
