# Event consumer
GenStage.start_link(MyConsumer, [])
Pros:
