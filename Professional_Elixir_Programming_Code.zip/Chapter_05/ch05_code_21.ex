defmodule MyApp.UserService do
Benefit: Reduces onboarding time for new developers and prevents technical debt.
