5.5 Case Study: Scalable Elixir System Design
Scenario: Real-Time Chat System
Requirements:
