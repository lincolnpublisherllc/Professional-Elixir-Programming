Elixir supports both monolithic and distributed designs:
