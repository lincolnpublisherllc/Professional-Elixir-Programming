Elixir Recommendation:Start with a 
modular monolith, then scale to microservices when business demands concurrency and distribution at scale.
