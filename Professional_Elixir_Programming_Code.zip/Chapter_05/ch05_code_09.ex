Benefit: Easier to test core logic in isolation.
