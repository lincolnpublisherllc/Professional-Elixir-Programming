  def send_message(pid, message) do
    GenServer.cast(pid, {:new_message, message})
  end
