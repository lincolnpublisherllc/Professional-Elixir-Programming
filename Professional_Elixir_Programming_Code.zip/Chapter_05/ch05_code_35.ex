Applied case study: real-time, scalable Elixir system design.
Professional Challenge:Design a 
modular e-commerce system in Elixir, implementing product, order, and user modules, and ensure it can handle thousands of concurrent users using supervisors and ETS caching.
