Use supervision trees for process-level decomposition:
defmodule MyApp.Application do
  use Application
