defmodule MyApp.Service do
  def fetch_data(id) do
    MyApp.Repo.get(MyApp.Schema, id)
  end
