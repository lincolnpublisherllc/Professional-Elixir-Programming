  def start_link(room_id), do: GenServer.start_link(__MODULE__, %{id: room_id, messages: []})
