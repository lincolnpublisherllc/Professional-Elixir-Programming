Elixir Implementation: GenStage and Broadway pipelines.
# Event producer
GenStage.start_link(MyProducer, [])
