Example:
defmodule MyApp.Core do
  def process(data) do
    # Pure business logic
    Enum.map(data, &(&1 * 2))
  end
