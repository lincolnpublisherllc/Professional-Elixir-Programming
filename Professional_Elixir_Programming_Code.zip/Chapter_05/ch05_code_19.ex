Horizontal scaling: Distribute workload across nodes.
Vertical scaling: Optimize memory, processes, and message passing.
Example: Use Task.async_stream for processing large datasets concurrently.
