Ensure table types (:set, :ordered_set, :bag) match your access patterns.
