:observer – Visual tool for memory, processes, and CPU.
:recon – Advanced runtime introspection for memory and process analysis.
:fprof – Profiling function calls and memory usage.
Telemetry + Logger – Monitor metrics in live systems.
