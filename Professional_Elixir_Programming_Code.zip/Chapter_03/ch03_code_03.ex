Lightweight Processes: Each Elixir process runs in isolation with its own memory heap.
Immutable Data: Variables are immutable; this simplifies memory safety and concurrency.
Message Passing: Processes communicate via copying messages rather than shared memory.
Process Heaps: Each process maintains its own heap, allowing garbage collection to occur independently.
Diagram: BEAM Memory Overview
