Diagram: BEAM Memory Overview52
