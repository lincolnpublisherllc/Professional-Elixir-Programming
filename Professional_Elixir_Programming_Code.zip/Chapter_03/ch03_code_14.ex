Use Task.async/await for isolated, disposable computations.
