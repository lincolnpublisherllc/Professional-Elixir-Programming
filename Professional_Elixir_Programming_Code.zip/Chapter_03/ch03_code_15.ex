# Inefficient
case value do
  x when is_integer(x) -> :integer
  x when is_binary(x) -> :binary
