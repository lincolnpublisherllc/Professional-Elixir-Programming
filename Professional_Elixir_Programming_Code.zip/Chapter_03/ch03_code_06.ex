Minor GC vs Major GC:
Minor GC: Cleans small temporary allocations.
Major GC: Cleans the entire heap when it exceeds a threshold.
spawn(fn ->
  large_list = Enum.to_list(1..1_000_000)
  IO.inspect(Enum.sum(large_list))
end)
