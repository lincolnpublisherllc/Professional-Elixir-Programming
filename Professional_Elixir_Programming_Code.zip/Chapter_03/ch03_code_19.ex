Benchmark critical pipelines using Benchee or custom timers.
