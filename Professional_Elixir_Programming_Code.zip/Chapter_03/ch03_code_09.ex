Avoid concatenating binaries repeatedly in loops; use IO.iodata or :binary.list_to_bin/1.
