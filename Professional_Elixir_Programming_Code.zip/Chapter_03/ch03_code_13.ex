Avoid shared state; use GenServer or Agents for controlled mutable state.
