Identify memory leaks:
:recon.proc_count()
:recon.top(:memory, 5)
Output: Top 5 processes consuming the most memory.
