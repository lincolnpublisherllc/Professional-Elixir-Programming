3.1 Understanding the Erlang VM (BEAM) Memory Model
