Example: Track top memory-consuming processes
:observer.start()
