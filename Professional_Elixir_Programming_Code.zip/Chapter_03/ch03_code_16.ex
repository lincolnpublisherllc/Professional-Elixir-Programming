# Optimized
case value do
  i when is_integer(i) -> :integer
  b when is_binary(b) -> :binary
