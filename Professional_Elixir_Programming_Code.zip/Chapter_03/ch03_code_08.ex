# Inefficient
1..1_000_000 |> Enum.map(&(&1 * 2)) |> Enum.sum()
# Optimized (streaming)
1..1_000_000 |> Stream.map(&(&1 * 2)) |> Enum.sum()
